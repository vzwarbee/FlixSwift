import  Axios  from "./Axios";

// register user

const registerService = async (user) => {
  const { data } = await Axios.post("/users", user);
  if (data) {
    localStorage.setItem("userInfo", JSON.stringify(data));
  }
  return data;
};

// logout user

const logoutService = () => {
  localStorage.removeItem("userInfo");
  return null;
};

// login user

const loginService = async (user) => {
  const { data } = await Axios.post("/users", user);
  if (data) {
    localStorage.setItem("userInfo", JSON.stringify(data));
  }
  return data;
};

export { registerService, logoutService, loginService };
